/// <reference path="./vendor/babylon.d.ts" />


console.log('Hello world');
const canvas = document.getElementById('renderCanvas');
//Create a Babylon js engine
const engine =  new BABYLON.Engine(canvas,true);

function createScene1(){
    //create a scene
    const scene =  new BABYLON.Scene(engine);

    //create a Camera
    const camera = new BABYLON.FreeCamera('camera',new BABYLON.Vector3(0,0,-10),scene);
    camera.attachControl(canvas,true);
    //Create a light
    const light = new BABYLON.HemisphericLight('light',new BABYLON.Vector3(0,1,0),scene);
    const ground = BABYLON.MeshBuilder.CreateGround("ground", {width:10, height:10});
    const box =  BABYLON.MeshBuilder.CreateBox('box',{size:1},scene);
    box.rotation.x=2;
    box.rotation.y=4;
   
    // const sphere =  BABYLON.MeshBuilder.CreateSphere('sphere',{segments:32,diameter:3},scene);
    // sphere.position = new BABYLON.Vector3(3,0,0);
    
    // const plane =BABYLON.MeshBuilder.CreatePlane('plane',{},scene);
    // plane.position =  new BABYLON.Vector3(-3,0,0);

    // const points = [
    //         new BABYLON.Vector3(2,0,10),
    //         new BABYLON.Vector3(2,1,1),
    //         new BABYLON.Vector3(2,1,0)];

    //         const lines =   BABYLON.MeshBuilder.CreateLines('lines',{points},scene);


    const material = new BABYLON.StandardMaterial('material',scene);
    material.diffuseColor =  new BABYLON.Color3(0,1,0);
    material.emissiveColor =  new BABYLON.Color3(1,0,0);
    const material2 = new BABYLON.StandardMaterial('material',scene);
    material2.diffuseTexture =  new BABYLON.Texture()
    box.material =  material;
    return scene;
}

const createScene =  () => {
    const scene = new BABYLON.Scene(engine);
    const camera = new BABYLON.UniversalCamera("camera", -Math.PI / 2, Math.PI / 2.5, 10, new BABYLON.Vector3(0, 0, 0),scene);
    //const camera = new BABYLON.FreeCamera('camera',new BABYLON.Vector3(0,0,-10),scene);
    camera.attachControl(canvas, true);
    const light = new BABYLON.HemisphericLight("light", new BABYLON.Vector3(1, 1, 0));
    faceUV = [];
    faceUV[0] = new BABYLON.Vector4(0.5, 0.0, 0.75, 1.0); //rear face
    faceUV[1] = new BABYLON.Vector4(0.0, 0.0, 0.25, 1.0); //front face
    faceUV[2] = new BABYLON.Vector4(0.25, 0, 0.5, 1.0); //right side
    faceUV[3] = new BABYLON.Vector4(0.75, 0, 1.0, 1.0); //left side
    const box = BABYLON.MeshBuilder.CreateBox("box",  {faceUV: faceUV, wrap: true});
    box.position.y = 0.5;
    const ground = BABYLON.MeshBuilder.CreateGround("ground", {width:10, height:10},scene);

    return scene;
}
const scene = createScene();

engine.runRenderLoop(()=>{
    scene.render();
});

