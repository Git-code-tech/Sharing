BABYLON.SceneLoader.ImportMesh("him", "/assests/", "Dude.babylon"
, scene
,function(result){
    var dude = result.meshes[0];
    dude.scaling = new BABYLON.Vector3(0.0001, 0.0001, 0.0001);

    dude.position = new BABYLON.Vector3(-6, 0, 0);
    dude.rotate(BABYLON.Axis.Y, BABYLON.Tools.ToRadians(-95), BABYLON.Space.LOCAL);
    const startRotation = dude.rotationQuaternion.clone();    
        
    scene.beginAnimation(result.skeletons[0], 0, 100, true, 1.0);

    let distance = 0;
    let step = 0.015;
    let p = 0;

    scene.onBeforeRenderObservable.add(() => {
        dude.movePOV(0, 0, step);
        distance += step;
        
        if (distance > track[p].dist) {
                
            dude.rotate(BABYLON.Axis.Y, BABYLON.Tools.ToRadians(track[p].turn), BABYLON.Space.LOCAL);
            p +=1;
            p %= track.length; 
            if (p === 0) {
                distance = 0;
                dude.position = new BABYLON.Vector3(-6, 0, 0);
                dude.rotationQuaternion = startRotation.clone();
            }
        }
        
    })
});   